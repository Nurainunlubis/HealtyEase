package com.example.latihanflutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
