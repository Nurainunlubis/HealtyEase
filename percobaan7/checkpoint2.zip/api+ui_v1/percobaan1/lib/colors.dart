import 'package:flutter/material.dart';

class AppColors {
  static const Color primaryColor = Color(0xFF095259); // Warna utama
  static const Color accentColor = Color(0xFF5790AB); // Warna aksen
  static const Color White = Color(0xFFFFFFFF); // Warna latar belakang
  static const Color Black = Color(0xFF000000); // Warna teks
  static const Color blue = Color(0xFF0099FF); // Warna teks
  static const Color grey = Color(0xFF828282); // Warna teks

  // Tambahkan warna lain sesuai kebutuhan
}
